# Sample exam

Open Student-exam.html. Download the CSV linked in each question and use R to analyze the data.

Submit the requested numerical answers, figures, and written explanations, labeled by question and part.

The exam has individual CSV links and one download containing all eight datasets. The CSV files are also included in the data folder.
